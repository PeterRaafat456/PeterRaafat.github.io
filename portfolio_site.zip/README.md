# Peter Raafat Adly - Portfolio Website

This repository contains a simple, professional static portfolio website for **{name}** built for GitHub Pages.

## What is included
- `index.html` - Main portfolio page
- `style.css` - Styling for the site
- `Peter_Raafat_Adly_Portfolio.pptx` - Original PPTX presentation (downloadable from the site)

## How to publish on GitHub Pages
1. Create a new repository on GitHub named `yourusername.github.io` (replace `yourusername`).
2. Upload the files in this folder (`index.html`, `style.css`, and the pptx file).
3. Commit to the `main` branch.
4. Go to **Settings > Pages**, set the branch to `main` and folder to `/ (root)`, then save.
5. Your site will be available at `https://yourusername.github.io` within a few minutes.

## Edit content
Open `index.html` and edit sections such as About, Work Experience, Projects, and Contact directly.

---
Contact: peterrafat263@gmail.com
